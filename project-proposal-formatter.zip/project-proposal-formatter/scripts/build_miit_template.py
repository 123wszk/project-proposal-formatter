# -*- coding: utf-8 -*-
"""构建「工信部（MIIT）项目技术标书」Word 样式模板。

用法: python build_miit_template.py <out.docx>

产出模板预置（对应 references/format-bid-miit.md）：
  - 页面：A4，上下 2.54cm、左右 3.17cm（§ 9，待确认项 #6）
  - Normal（正文）：仿宋 小四、固定值 28 磅、首行缩进 2 字符、两端对齐（§ 5）
  - 「标题 1」~「标题 5」：重定义内置样式（§ 2.2）+ 多级列表自动编号绑定（§ 2.1 方案 A）
  - 「题注」(Caption)：仿宋 小四、固定值 28 磅、居中、无缩进（§ 3 / § 4）
  - 「表格文字」(自定义段落样式)：仿宋 五号、单倍行距、居中、无缩进（§ 4）
  - 页脚：居中页码（仿宋 五号）（§ 9）

编号口径：默认采用**方案 A（Word 多级列表自动编号，绑定标题 1~5）**。
若团队改用**方案 B（手打编号）**：删除 numbering.xml 里 abstractNumId/numId=100 的条目，
并把标题段落里自动出现的编号去掉即可（标题样式本身不含编号文本）。

关键防坑：
  - 中文字体只写 w:eastAsia，西文留 Times New Roman（避免数字/英文外观被改）；
  - 标题样式必须显式清零 firstLineChars/firstLine，否则会继承 Normal 的首行缩进；
  - 表格内段落不继承正文行距，必须显式设「表格文字」样式；
  - rPr / pPr / style 的子元素顺序必须符合 OOXML schema，否则 Word 报「文件可能已经损坏」。
"""
import sys
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, Cm
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL

EA = '仿宋'
LATIN = 'Times New Roman'

STYLE_ORDER = ['w:name', 'w:aliases', 'w:basedOn', 'w:next', 'w:link', 'w:autoRedefine',
               'w:hidden', 'w:uiPriority', 'w:semiHidden', 'w:unhideWhenUsed', 'w:qFormat',
               'w:locked', 'w:personal', 'w:personalCompose', 'w:personalReply', 'w:rsid',
               'w:pPr', 'w:rPr', 'w:tblPr', 'w:trPr', 'w:tcPr', 'w:tblStylePr']
PPR_ORDER = ['w:pStyle', 'w:keepNext', 'w:keepLines', 'w:pageBreakBefore', 'w:framePr',
             'w:widowControl', 'w:numPr', 'w:suppressLineNumbers', 'w:pBdr', 'w:shd', 'w:tabs',
             'w:suppressAutoHyphens', 'w:kinsoku', 'w:wordWrap', 'w:overflowPunct',
             'w:topLinePunct', 'w:autoSpaceDE', 'w:autoSpaceDN', 'w:bidi', 'w:adjustRightInd',
             'w:snapToGrid', 'w:spacing', 'w:ind', 'w:contextualSpacing', 'w:mirrorIndents',
             'w:suppressOverlap', 'w:jc', 'w:textDirection', 'w:textAlignment',
             'w:textboxTightWrap', 'w:outlineLvl', 'w:divId', 'w:cnfStyle', 'w:rPr',
             'w:sectPr', 'w:pPrChange']
RPR_ORDER = ['w:rStyle', 'w:rFonts', 'w:b', 'w:bCs', 'w:i', 'w:iCs', 'w:caps', 'w:smallCaps',
             'w:strike', 'w:dstrike', 'w:outline', 'w:shadow', 'w:emboss', 'w:imprint',
             'w:noProof', 'w:snapToGrid', 'w:vanish', 'w:webHidden', 'w:color', 'w:spacing',
             'w:w', 'w:kern', 'w:position', 'w:sz', 'w:szCs', 'w:highlight', 'w:u', 'w:effect',
             'w:bdr', 'w:shd', 'w:fitText', 'w:vertAlign', 'w:rtl', 'w:cs', 'w:em', 'w:lang',
             'w:eastAsianLayout', 'w:specVanish', 'w:oMath']


def ins(parent, child, order):
    """按 schema 顺序插入 child。"""
    idx = {qn(n): i for i, n in enumerate(order)}
    name = idx.get(child.tag, len(order))
    for ex in parent:
        if idx.get(ex.tag, len(order)) > name:
            ex.addprevious(child)
            return child
    parent.append(child)
    return child


def rm(parent, *tags):
    for t in tags:
        for e in parent.findall(qn(t)):
            parent.remove(e)


def style_pPr(style):
    e = style.element
    ppr = e.find(qn('w:pPr'))
    if ppr is None:
        ppr = OxmlElement('w:pPr')
        ins(e, ppr, STYLE_ORDER)
    return ppr


def style_rPr(style):
    e = style.element
    rpr = e.find(qn('w:rPr'))
    if rpr is None:
        rpr = OxmlElement('w:rPr')
        ins(e, rpr, STYLE_ORDER)
    return rpr


def set_font(rpr, ea=EA, latin=LATIN, hint='eastAsia'):
    rf = rpr.find(qn('w:rFonts'))
    if rf is None:
        rf = OxmlElement('w:rFonts')
        ins(rpr, rf, RPR_ORDER)
    rf.set(qn('w:ascii'), latin)
    rf.set(qn('w:hAnsi'), latin)
    rf.set(qn('w:cs'), latin)
    rf.set(qn('w:eastAsia'), ea)
    # 清掉主题字体属性，避免其覆盖显式字体名
    for a in ('w:asciiTheme', 'w:hAnsiTheme', 'w:eastAsiaTheme', 'w:cstheme'):
        if rf.get(qn(a)) is not None:
            rf.attrib.pop(qn(a))
    if hint:
        rf.set(qn('w:hint'), hint)


def set_el(parent, tag, order, **attrs):
    e = parent.find(qn(tag))
    if e is None:
        e = OxmlElement(tag)
        ins(parent, e, order)
    for k, v in attrs.items():
        if v is None:
            continue
        e.set(qn(k), str(v))
    return e


def fmt_style(style, *, ea=EA, latin=LATIN, sz=None, bold=None,
              line=None, rule=None, before_lines=None, after_lines=None,
              before=None, after=None, ind=None, align=None,
              outline=None, keep_next=False, color='auto'):
    """统一设置段落样式：字体/字号/加粗/行距/缩进/对齐/大纲级别。"""
    ppr = style_pPr(style)
    rpr = style_rPr(style)
    # 字体
    set_font(rpr, ea, latin)
    rm(rpr, 'w:sz', 'w:szCs', 'w:b', 'w:bCs', 'w:i', 'w:iCs', 'w:u', 'w:color')
    if sz is not None:
        set_el(rpr, 'w:sz', RPR_ORDER, **{'w:val': sz})
        set_el(rpr, 'w:szCs', RPR_ORDER, **{'w:val': sz})
    if bold is not None:
        v = '1' if bold else '0'
        set_el(rpr, 'w:b', RPR_ORDER, **{'w:val': v})
        set_el(rpr, 'w:bCs', RPR_ORDER, **{'w:val': v})
    set_el(rpr, 'w:color', RPR_ORDER, **{'w:val': color})
    # 行距 / 间距
    if line is not None or before_lines is not None or after_lines is not None \
            or before is not None or after is not None:
        attrs = {}
        if line is not None:
            attrs['w:line'] = line
            attrs['w:lineRule'] = rule or 'auto'
        if before_lines is not None:
            attrs['w:beforeLines'] = before_lines
            attrs['w:before'] = before if before is not None else 0
        elif before is not None:
            attrs['w:before'] = before
        if after_lines is not None:
            attrs['w:afterLines'] = after_lines
            attrs['w:after'] = after if after is not None else 0
        elif after is not None:
            attrs['w:after'] = after
        set_el(ppr, 'w:spacing', PPR_ORDER, **attrs)
    # 缩进
    if ind is not None:
        set_el(ppr, 'w:ind', PPR_ORDER, **ind)
    # 对齐
    if align is not None:
        set_el(ppr, 'w:jc', PPR_ORDER, **{'w:val': align})
    # 大纲级别
    if outline is not None:
        set_el(ppr, 'w:outlineLvl', PPR_ORDER, **{'w:val': outline})
    # 与下段同页
    if keep_next:
        set_el(ppr, 'w:keepNext', PPR_ORDER, **{'w:val': '1'})
    # 不用自动断词等噪声：保持精简
    return style


def based_on_none(style):
    """断开样式的 basedOn 链。

    目的：Normal（正文）带首行缩进 2 字符，若标题样式 basedOn Normal，会**继承**
    firstLineChars=200，从而覆盖 / 吃掉标题的 w:hanging，悬挂缩进失效（Word 实测）。
    断开后标题只继承 docDefaults（无缩进），悬挂缩进才生效。
    """
    e = style.element
    for b in e.findall(qn('w:basedOn')):
        e.remove(b)


def set_numpr(style, ilvl, numid):
    """把段落样式直接绑定到多级列表的某一级（比只靠 lvl/pStyle 联动更可靠）。"""
    ppr = style_pPr(style)
    rm(ppr, 'w:numPr')
    np = OxmlElement('w:numPr')
    il = OxmlElement('w:ilvl'); il.set(qn('w:val'), str(ilvl)); np.append(il)
    ni = OxmlElement('w:numId'); ni.set(qn('w:val'), str(numid)); np.append(ni)
    ins(ppr, np, PPR_ORDER)


def add_multilevel_numbering(doc, absid=100, numid=100):
    """新建多级列表并绑定到「标题 1~5」：1 / 1.1 / 1.1.1 / 1.1.1.1 / 1.1.1.1.1，分隔符=空格。"""
    root = doc.part.numbering_part.element
    lvls = [(0, 'Heading1', 431), (1, 'Heading2', 720), (2, 'Heading3', 720),
            (3, 'Heading4', 720), (4, 'Heading5', 720)]
    an = OxmlElement('w:abstractNum')
    an.set(qn('w:abstractNumId'), str(absid))
    an.append(OxmlElement('w:nsid'))
    an[-1].set(qn('w:val'), '1A2B3C4D')
    mlt = OxmlElement('w:multiLevelType')
    mlt.set(qn('w:val'), 'multilevel')
    an.append(mlt)
    tmpl = OxmlElement('w:tmpl')
    tmpl.set(qn('w:val'), '1A2B3C4D')
    an.append(tmpl)
    for ilvl, ps, hang in lvls:
        lv = OxmlElement('w:lvl')
        lv.set(qn('w:ilvl'), str(ilvl))
        st = OxmlElement('w:start'); st.set(qn('w:val'), '1'); lv.append(st)
        nf = OxmlElement('w:numFmt'); nf.set(qn('w:val'), 'decimal'); lv.append(nf)
        pst = OxmlElement('w:pStyle'); pst.set(qn('w:val'), ps); lv.append(pst)
        sf = OxmlElement('w:suff'); sf.set(qn('w:val'), 'space'); lv.append(sf)
        lt = OxmlElement('w:lvlText')
        lt.set(qn('w:val'), '.'.join('%%%d' % (i + 1) for i in range(ilvl + 1)))
        lv.append(lt)
        lj = OxmlElement('w:lvlJc'); lj.set(qn('w:val'), 'left'); lv.append(lj)
        lp = OxmlElement('w:pPr')
        li = OxmlElement('w:ind')
        li.set(qn('w:left'), str(hang)); li.set(qn('w:hanging'), str(hang))
        lp.append(li); lv.append(lp)
        lr = OxmlElement('w:rPr')
        rf = OxmlElement('w:rFonts')
        rf.set(qn('w:ascii'), LATIN); rf.set(qn('w:hAnsi'), LATIN)
        rf.set(qn('w:cs'), LATIN); rf.set(qn('w:eastAsia'), EA); rf.set(qn('w:hint'), 'eastAsia')
        lr.append(rf); lv.append(lr)
        an.append(lv)
    # abstractNum 必须在所有 w:num 之前
    first_num = root.find(qn('w:num'))
    if first_num is not None:
        first_num.addprevious(an)
    else:
        root.append(an)
    num = OxmlElement('w:num'); num.set(qn('w:numId'), str(numid))
    aid = OxmlElement('w:abstractNumId'); aid.set(qn('w:val'), str(absid))
    num.append(aid)
    root.append(num)


def set_doc_defaults(doc, ea=EA, latin=LATIN, sz='24'):
    dd = doc.styles.element.find(qn('w:docDefaults'))
    if dd is None:
        return
    rpr_def = dd.find(qn('w:rPrDefault'))
    if rpr_def is None:
        rpr_def = OxmlElement('w:rPrDefault'); dd.insert(0, rpr_def)
    rpr = rpr_def.find(qn('w:rPr'))
    if rpr is None:
        rpr = OxmlElement('w:rPr'); rpr_def.append(rpr)
    set_font(rpr, ea, latin)
    rm(rpr, 'w:sz', 'w:szCs')
    set_el(rpr, 'w:sz', RPR_ORDER, **{'w:val': sz})
    set_el(rpr, 'w:szCs', RPR_ORDER, **{'w:val': sz})


def add_footer_pagenum(doc):
    p = doc.sections[0].footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ppr = p._p.get_or_add_pPr()
    rpr = ppr.find(qn('w:rPr'))
    if rpr is None:
        rpr = OxmlElement('w:rPr')
        ins(ppr, rpr, PPR_ORDER)
    set_font(rpr, EA, LATIN)
    set_el(rpr, 'w:sz', RPR_ORDER, **{'w:val': '21'})
    set_el(rpr, 'w:szCs', RPR_ORDER, **{'w:val': '21'})
    r1 = p.add_run()._r
    fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), 'begin'); r1.append(fc)
    r2 = p.add_run()._r
    it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = ' PAGE '
    r2.append(it)
    r3 = p.add_run()._r
    fc2 = OxmlElement('w:fldChar'); fc2.set(qn('w:fldCharType'), 'separate'); r3.append(fc2)
    p.add_run('1')
    r5 = p.add_run()._r
    fc3 = OxmlElement('w:fldChar'); fc3.set(qn('w:fldCharType'), 'end'); r5.append(fc3)


def add_seq_caption(doc, label, num_cache, text, ref_bm, toc_bm, bid):
    """插入 Word「插入题注」形态的题注（含 _Ref / _Toc 双书签 + SEQ 域）。"""
    p = doc.add_paragraph(style='Caption')
    el = p._p
    bs1 = OxmlElement('w:bookmarkStart'); bs1.set(qn('w:id'), str(bid)); bs1.set(qn('w:name'), ref_bm)
    el.append(bs1)
    p.add_run(label + ' ')
    r1 = p.add_run()._r
    fc = OxmlElement('w:fldChar'); fc.set(qn('w:fldCharType'), 'begin'); r1.append(fc)
    r2 = p.add_run()._r
    it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve')
    it.text = ' SEQ %s \\* ARABIC ' % label
    r2.append(it)
    r3 = p.add_run()._r
    fc2 = OxmlElement('w:fldChar'); fc2.set(qn('w:fldCharType'), 'separate'); r3.append(fc2)
    p.add_run(str(num_cache))
    r5 = p.add_run()._r
    fc3 = OxmlElement('w:fldChar'); fc3.set(qn('w:fldCharType'), 'end'); r5.append(fc3)
    be1 = OxmlElement('w:bookmarkEnd'); be1.set(qn('w:id'), str(bid)); el.append(be1)
    bs2 = OxmlElement('w:bookmarkStart'); bs2.set(qn('w:id'), str(bid + 1)); bs2.set(qn('w:name'), toc_bm)
    el.append(bs2)
    p.add_run(' ' + text)
    be2 = OxmlElement('w:bookmarkEnd'); be2.set(qn('w:id'), str(bid + 1)); el.append(be2)
    return p


def build(out_path):
    doc = Document()

    # ---- 页面设置 § 9 ----
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin = sec.bottom_margin = Cm(2.54)
    sec.left_margin = sec.right_margin = Cm(3.17)

    set_doc_defaults(doc)

    # ---- 多级列表自动编号绑定标题 1~5 § 2.1 方案 A（先建列表，供样式引用）----
    add_multilevel_numbering(doc)

    # ---- Normal = 正文 § 5：仿宋小四 / 固定值28磅 / 首行缩进2字符 / 两端对齐 ----
    fmt_style(doc.styles['Normal'], sz='24', bold=False, line='560', rule='exact',
              before='0', after='0',
              ind={'w:firstLineChars': '200', 'w:firstLine': '480'},
              align='both')

    # ---- 标题 1~5 § 2.2 ----
    H = {
        'Heading 1': dict(sz='32', bold=True, line='460', rule='exact',
                          before_lines='50', after_lines='50', hang=431, outline='0'),
        'Heading 2': dict(sz='32', bold=True, line='360', rule='auto',
                          before_lines='50', after_lines='50', hang=720, outline='1'),
        'Heading 3': dict(sz='24', bold=True, line='360', rule='auto',
                          before_lines='50', after_lines='50', hang=720, outline='2'),
        'Heading 4': dict(sz='24', bold=True, line='360', rule='auto',
                          before_lines='50', after_lines='50', hang=720, outline='3'),
        'Heading 5': dict(sz='24', bold=True, line='360', rule='auto',
                          before_lines='50', after_lines='50', hang=720, outline='4'),
    }
    for i, (name, cfg) in enumerate(H.items()):
        st = doc.styles[name]
        # 必须断开 basedOn，否则会继承 Normal 的 firstLineChars，悬挂缩进失效
        based_on_none(st)
        fmt_style(
            st, sz=cfg['sz'], bold=cfg['bold'], line=cfg['line'], rule=cfg['rule'],
            before_lines=cfg['before_lines'], after_lines=cfg['after_lines'],
            ind={'w:left': str(cfg['hang']), 'w:hanging': str(cfg['hang'])},
            align='left', outline=cfg['outline'], keep_next=True)
        # 绑定多级列表第 i 级（1 / 1.1 / 1.1.1 / …）
        set_numpr(st, i, 100)

    # ---- 题注 Caption § 3 / § 4：仿宋小四 / 固定值28磅 / 居中 / 无缩进 / 不加粗 ----
    fmt_style(doc.styles['Caption'], sz='24', bold=False, line='560', rule='exact',
              before='0', after='0',
              ind={'w:firstLine': '0', 'w:firstLineChars': '0', 'w:left': '0'}, align='center')

    # ---- 表格文字（自定义）§ 4：仿宋五号 / 单倍行距 / 居中 / 无缩进 ----
    if '表格文字' in [s.name for s in doc.styles]:
        tbl_style = doc.styles['表格文字']
    else:
        tbl_style = doc.styles.add_style('表格文字', WD_STYLE_TYPE.PARAGRAPH)
    fmt_style(tbl_style, sz='21', bold=False, line='240', rule='auto',
              before='0', after='0',
              ind={'w:firstLine': '0', 'w:firstLineChars': '0', 'w:left': '0'}, align='center')

    # ---- 页脚页码 § 9 ----
    add_footer_pagenum(doc)

    # ---- 示例内容（可整段删除）----
    doc.add_paragraph('【样式模板·示例内容，正式使用时请整段删除】本模板预置：正文＝仿宋小四·固定值28磅·'
                      '首行缩进2字符；标题1~5＝仿宋加粗·悬挂缩进·多级自动编号；表格文字＝仿宋五号·单倍行距·居中；'
                      '题注＝仿宋小四·固定值28磅·居中（含 SEQ 域）。')

    h1 = doc.add_heading('项目推进计划', level=1)
    doc.add_paragraph('本章说明项目总体推进安排。正文段落自动为仿宋小四、固定值28磅行距、'
                      '首行缩进2字符、两端对齐。')
    doc.add_heading('阶段目标', level=2)
    doc.add_paragraph('按里程碑分阶段推进，各阶段交付物与验收标准如下。')
    doc.add_heading('里程碑与交付物', level=3)
    doc.add_paragraph('三级标题示意段落。')
    doc.add_heading('关键路径', level=4)
    doc.add_paragraph('四级标题示意段落。')
    doc.add_heading('风险与应对', level=5)
    doc.add_paragraph('五级标题示意段落。')

    add_seq_caption(doc, '表', 1, '项目里程碑计划表', '_Ref90001', '_Toc90001', 90001)
    table = doc.add_table(rows=3, cols=3)
    try:
        table.style = 'Table Grid'
    except Exception:
        pass
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    head = ['序号', '里程碑', '完成时间']
    for j, t in enumerate(head):
        c = table.cell(0, j)
        c.text = ''
        cp = c.paragraphs[0]
        cp.style = doc.styles['表格文字']
        cp.add_run(t)
        c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    for i in range(1, 3):
        for j in range(3):
            c = table.cell(i, j)
            cp = c.paragraphs[0]
            cp.style = doc.styles['表格文字']
            cp.add_run('示例%d' % (j + 1))
            c.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

    doc.save(out_path)
    print('SAVED', out_path)


if __name__ == '__main__':
    build(sys.argv[1] if len(sys.argv) > 1 else 'miit-techbid-template.docx')
