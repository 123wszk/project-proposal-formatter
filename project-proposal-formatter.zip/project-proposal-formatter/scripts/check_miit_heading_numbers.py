# -*- coding: utf-8 -*-
"""MIIT 技术标书 —— 手打标题编号纠错（对应 references/format-bid-miit.md § 10.1）。

用法:
  python check_miit_heading_numbers.py <docx>                      # 只诊断
  python check_miit_heading_numbers.py <docx> --json report.json   # 另存 JSON 报告
  python check_miit_heading_numbers.py <docx> --fix out.docx       # 诊断并写出修正稿
  python check_miit_heading_numbers.py <docx> --quiet              # 只输出汇总

退出码: 0 = 无问题；1 = 发现问题（便于接进流水线）。

校验对象
  套了「标题 1~5」样式（styleId=Heading1..5，或样式名「标题 N」/「Heading N」），
  或段落带 w:outlineLvl 0~4 的**顶层段落**。
  —— 正文样式里的 （1）（2）（a）（b） 小标题**不参与**（它们本来不进目录、不编号，见 § 2.1）。

8 类检查
  1. 层级段数 ↔ 样式级别一致（标题 2 应写成 `1.1`，不能是 `1.1.1`）
  2. 同级连续（同一父级下子号从 1 递增，不跳号不重号）
  3. 父级存在与归属（出现 `1.2.1` 前必须出现过 `1.2`）
  4. 顶级连续（`1、2、3…`）
  5. 分隔符：编号与标题之间恰好一个半角空格（检出制表符 / 全角空格 / 无空格 / 多空格）
  6. 全角字符：编号里混入全角数字 / 全角句点 / 全角空格
  7. 前后缀杂讯：编号前多余空格、编号后紧跟非空格字符
  8. 缺编号：标题段落没有以数字编号开头

--fix 只做确定性修正：全角→半角、分隔符统一为一个半角空格、多余空格收紧、
按文档顺序重排各级编号（含补上缺失编号）。正文与 （1）（2） 段落一律不动。
⚠️ 修正会改写文字，务必先备份原文件。
"""
import sys
import re
import json
import copy
import argparse

from docx import Document
from docx.oxml.ns import qn

FW = {ord(c): ord('0123456789'[i]) for i, c in enumerate('０１２３４５６７８９')}
FW['．'] = '.'
FW['　'] = ' '

NUM_RE = re.compile(r'^([0-9０-９]+(?:[.．][0-9０-９]+)*)')


def norm_num(s):
    return s.translate(FW)


def heading_level(p):
    """返回该段落的标题级别（1~5），非标题返回 None。"""
    sid = (p.style.style_id or '')
    m = re.match(r'^Heading\s*([1-9])$', sid, re.I)
    if m:
        return int(m.group(1))
    name = (p.style.name or '').strip()
    m = re.match(r'^(?:标题|Heading)\s*([1-9])$', name, re.I)
    if m:
        return int(m.group(1))
    ppr = p._p.find(qn('w:pPr'))
    if ppr is not None:
        ol = ppr.find(qn('w:outlineLvl'))
        if ol is not None:
            v = ol.get(qn('w:val'))
            if v is not None and v.isdigit() and 0 <= int(v) <= 4:
                return int(v) + 1
    return None


def para_text(p):
    """拼接段落内所有 w:t（含 hyperlink 里的）。"""
    buf = []
    for t in p._p.iter(qn('w:t')):
        buf.append(t.text or '')
    return ''.join(buf)


def set_para_text(p, text):
    """改写段落文字，保留首个 run 的 rPr。"""
    runs = list(p._p.findall(qn('w:r')))
    rpr = None
    if runs:
        r = runs[0].find(qn('w:rPr'))
        if r is not None:
            rpr = copy.deepcopy(r)
    for r in runs:
        p._p.remove(r)
    run = p.add_run(text)
    if rpr is not None:
        run._r.insert(0, rpr)


def check(doc):
    """返回 issues 列表；每项含 para_index / style / level / text / issues / suggested。"""
    heads = []
    for idx, p in enumerate(doc.paragraphs):
        lvl = heading_level(p)
        if lvl is None:
            continue
        raw = para_text(p)
        if not raw.strip():
            continue
        heads.append((idx, lvl, p, raw))

    issues = []
    seen = {}            # 已出现的编号元组 -> True（用于父级存在性判断）
    sib_last = {}        # 父级元组 -> 该父级下最后一个子号（用于同级连续）
    expected_prev = {}   # 便于 --fix 生成

    for idx, lvl, p, txt in heads:
        probs = []
        # 拆前缀空格 + 编号 + 其余
        m_lead = re.match(r'^(\s*)', txt)
        lead_ws = m_lead.group(1)
        body = txt[len(lead_ws):]
        m = NUM_RE.match(body)
        if m:
            raw_num = m.group(1)
            rest = body[len(raw_num):]
        else:
            raw_num = None
            rest = body

        # --- 计算"期望编号" ---
        if lvl == 1:
            expected = (sib_last.get((), 0) + 1,)
        else:
            parent = tuple(expected_prev.get(('last_at_level', lvl - 1)) or ())
            if len(parent) != lvl - 1:
                parent = (parent + (1,) * lvl)[:lvl - 1]
            expected = parent + (sib_last.get(parent, 0) + 1,)

        # --- 逐项检查 ---
        if raw_num is None:
            probs.append(('缺编号', '标题段落没有以数字编号开头'))
        else:
            # 6 全角
            if any(ch in raw_num for ch in '０１２３４５６７８９．'):
                probs.append(('全角字符', '编号含全角数字/句点，应改半角'))
            num = norm_num(raw_num)
            comps = num.split('.')
            # 1 层级
            if len(comps) != lvl:
                probs.append(('层级不符', '标题 %d 级应为 %d 段编号，实际为 %s（%d 段）'
                              % (lvl, lvl, raw_num, len(comps))))
            # 5 分隔符
            if rest.startswith('\t'):
                probs.append(('分隔符', '编号后用制表符，应为**一个半角空格**'))
            elif rest.startswith('　'):
                probs.append(('分隔符', '编号后用全角空格，应为**一个半角空格**'))
            elif rest and not rest.startswith(' '):
                probs.append(('分隔符', '编号与标题之间缺空格'))
            elif rest.startswith('  '):
                probs.append(('分隔符', '编号与标题之间有多个空格，应收紧为一个'))
            # 7 前缀杂讯
            if lead_ws:
                probs.append(('前后缀杂讯', '编号前有多余空白字符'))
            # 2/3/4 连续性（仅当段数正确时才用完整元组判断，避免误报级联）
            if len(comps) == lvl:
                cur = tuple(int(x) for x in comps)
                # 3 父级归属
                if lvl > 1 and cur[:-1] not in seen:
                    probs.append(('父级缺失', '找不到上级编号 %s'
                                  % '.'.join(str(x) for x in cur[:-1])))
                # 4 顶级连续
                if lvl == 1 and cur[0] != expected[0]:
                    probs.append(('顶级不连续', '应为 %d，实际为 %d' % (expected[0], cur[0])))
                # 2 同级连续
                if lvl > 1:
                    exp_child = sib_last.get(cur[:-1], 0) + 1
                    if cur[-1] != exp_child:
                        probs.append(('同级不连续', '在父级 %s 下应为 %d，实际为 %d'
                                      % ('.'.join(str(x) for x in cur[:-1]) or '-',
                                         exp_child, cur[-1])))

        clean_title = body[len(raw_num):] if raw_num else body
        clean_title = clean_title.replace('\t', ' ').replace('　', ' ').strip()
        suggested = '%s %s' % ('.'.join(str(x) for x in expected), clean_title)

        # 推进期望状态（按"文档顺序 + 修正后"的顺序推进，便于 --fix 重排）
        if lvl > 1:
            parent = expected[:-1]
            sib_last[parent] = expected[-1]
        else:
            sib_last[()] = expected[0]
        seen[expected] = True
        expected_prev[('last_at_level', lvl)] = expected
        # 出现更深层编号时，清掉更深层的历史
        for k in list(sib_last):
            if len(k) >= lvl + 1:
                del sib_last[k]

        if probs:
            issues.append(dict(para_index=idx, level=lvl, style=p.style.name,
                               text=txt, problems=probs, suggested=suggested,
                               para=p))
    return issues


def main():
    ap = argparse.ArgumentParser(description='MIIT 手打标题编号纠错')
    ap.add_argument('docx')
    ap.add_argument('--json', dest='json_out', default=None)
    ap.add_argument('--fix', dest='fix_out', default=None,
                    help='写出修正稿路径（先备份原文件！）')
    ap.add_argument('--quiet', action='store_true')
    args = ap.parse_args()

    doc = Document(args.docx)
    issues = check(doc)

    if not args.quiet:
        if not issues:
            print('✅ 标题编号检查通过：未发现 1~5 级目录标题编号问题。')
        else:
            print('❌ 发现 %d 处标题编号问题：\n' % len(issues))
            print('%-4s %-6s %-8s %-30s %-12s %s' % ('段落', '级别', '样式', '原文', '问题', '建议'))
            print('-' * 120)
            for it in issues:
                types = ' / '.join(t for t, _ in it['problems'])
                print('%-4d %-6d %-8s %-30s %-12s %s' % (
                    it['para_index'], it['level'], it['style'],
                    it['text'][:28], types, it['suggested'][:40]))
                for t, d in it['problems']:
                    print('        ↳ %s：%s' % (t, d))
    else:
        print('发现 %d 处问题。' % len(issues))

    if args.json_out:
        data = [dict(para_index=i['para_index'], level=i['level'], style=i['style'],
                     text=i['text'], problems=[dict(type=t, detail=d) for t, d in i['problems']],
                     suggested=i['suggested']) for i in issues]
        with open(args.json_out, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print('JSON 报告已写出：', args.json_out)

    if args.fix_out:
        for it in issues:
            set_para_text(it['para'], it['suggested'])
        doc.save(args.fix_out)
        print('修正稿已写出：', args.fix_out, '（共改写 %d 处）' % len(issues))

    sys.exit(0 if not issues else 1)


if __name__ == '__main__':
    main()
