# -*- coding: utf-8 -*-
"""校验 MIIT 技术标书模板 / 成品的「目录页」是否符合 § 7 规范。

用法:
    python verify_miit_toc.py <in.docx> [workdir]

做的事（对应 references/format-bid-miit.md § 7.2）：
  1. Word COM 打开 → 更新 TOC 域 + 全部域 → Repaginate（"文件能否被 Word 打开"的硬校验）
  2. 打印目录条目：样式名 / 页码
  3. 回读每条目录段落的 中文字体 / 西文字体 / 字号 / 加粗 / 左缩进 / 首行缩进 / 行距
  4. 检查 styles.xml 里是否存在**同名重复**的 `toc N` 样式（§ 7.1 坑 1）
  5. 回存 docx + 导出 PDF → pypdfium2 取字符坐标，核对一级起点 = 左页边距、
     每级 +2 字符、页码右边缘 = 右页边界（§ 7.1 坑 2）
  6. 栅格化 PDF 每页为 PNG，供肉眼核对

依赖: pywin32(win32com) + pypdfium2。退出码 1 表示发现明显问题。
"""
import os
import re
import sys
import zipfile
import tempfile
import collections

TOC_TAB_TWIPS = 8306          # 右制表位（twips）
TWIP_PER_PT = 20.0
PT_PER_CM = 72 / 2.54


def cm2pt(v):
    return v * PT_PER_CM


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    src = os.path.abspath(sys.argv[1])
    # 默认写到系统临时目录，避免污染技能 / 项目目录（否则会被打包进 zip）
    wd = os.path.abspath(sys.argv[2]) if len(sys.argv) > 2 else os.path.join(
        tempfile.gettempdir(), 'miit_toc_verify')
    os.makedirs(wd, exist_ok=True)
    out_docx = os.path.join(wd, 'roundtrip.docx')
    out_pdf = os.path.join(wd, 'roundtrip.pdf')

    problems = []

    # ---------- 1~3. Word COM ----------
    import win32com.client as win32
    word = win32.gencache.EnsureDispatch('Word.Application')
    word.Visible = False
    word.DisplayAlerts = 0
    try:
        doc = word.Documents.Open(src, ReadOnly=False)
        n_toc = doc.TablesOfContents.Count
        print('[1] Word 打开成功；TablesOfContents 数 = %d' % n_toc)
        if n_toc == 0:
            problems.append('文档中没有 TOC 域（目录页缺失）')

        for i in range(1, n_toc + 1):
            doc.TablesOfContents(i).Update()
        for i in range(1, doc.Fields.Count + 1):
            try:
                doc.Fields(i).Update()
            except Exception as e:
                print('    域 %d 更新失败（可忽略）: %s' % (i, e))
        doc.Repaginate()
        print('    总页数 = %d' % doc.ComputeStatistics(2))

        if n_toc:
            print('[2] 目录条目（样式 / 页码 / 缩进 / 字体）:')
            levels_seen = set()
            for p in doc.TablesOfContents(1).Range.Paragraphs:
                t = p.Range.Text.strip()
                if not t:
                    continue
                st = str(p.Style.NameLocal) if p.Style else '?'
                m = re.search(r'(\d+)\s*$', st)
                if m:
                    levels_seen.add(int(m.group(1)))
                f, pf = p.Range.Font, p.Format
                print('    [%-6s] %-30s first=%5.2f left=%6.2f | %s/%s %.1fpt bold=%s'
                      % (st, t[:30], pf.FirstLineIndent, pf.LeftIndent,
                         f.NameFarEast, f.NameAscii, f.Size, bool(f.Bold)))
                if abs(pf.FirstLineIndent) > 0.6:
                    problems.append('目录条目首行缩进 %.2fpt ≠ 0（疑似继承了 Normal）：%s'
                                    % (pf.FirstLineIndent, t[:24]))
                if str(f.NameFarEast) != '仿宋':
                    problems.append('目录条目中文字体 %s ≠ 仿宋：%s' % (f.NameFarEast, t[:24]))
            miss = [i for i in range(1, 6) if i not in levels_seen]
            if miss:
                problems.append('目录未抓到 %s 级标题（若文档本身无该级标题属正常）'
                                % '/'.join(str(i) for i in miss))
            else:
                print('    ✔ 目录 1~5 级样式全部出现')

        # 目录页独立起页 & 正文一级标题独立起页
        for p in doc.Paragraphs:
            t = p.Range.Text.strip()
            if t in ('目  录', '目录'):
                print('[+] 目录标题：page=%s style=%s'
                      % (p.Range.Information(3), p.Style.NameLocal))
            elif t == '1 项目推进计划':
                print('[+] 正文首个一级标题：page=%s style=%s'
                      % (p.Range.Information(3), p.Style.NameLocal))

        doc.SaveAs2(out_docx)
        doc.ExportAsFixedFormat(out_pdf, 17)
        doc.Close(SaveChanges=False)
    finally:
        word.Quit()

    # ---------- 4. 同名重复 toc 样式 ----------
    print('[4] styles.xml 中 toc 样式：')
    with zipfile.ZipFile(out_docx) as z:
        s = z.read('word/styles.xml').decode('utf-8')
    names = collections.Counter()
    for blk in re.findall(r'<w:style\b.*?</w:style>', s, re.S):
        nm = re.search(r'<w:name w:val="([^"]+)"', blk)
        if not nm or not nm.group(1).lower().startswith('toc '):
            continue
        sid = re.search(r'w:styleId="([^"]+)"', blk).group(1)
        custom = 'customStyle' in blk
        tab = re.search(r'<w:tab [^>]*w:leader="dot"[^>]*/>', blk)
        print('    id=%-6s custom=%-5s dot-tab=%s' % (sid, custom, bool(tab)))
        names[nm.group(1).lower()] += 1
    dup = [k for k, v in names.items() if v > 1]
    if dup:
        problems.append('存在同名重复 TOC 样式 %s（§ 7.1 坑 1：Word 会旁路自定义缩进）' % dup)
    else:
        print('    ✔ 无同名重复')

    # ---------- 5. PDF 字符坐标 ----------
    print('[5] PDF 字符坐标核对（一级起点应≈左页边距；页码右边缘应≈右页边界）:')
    try:
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(out_pdf)
        loc = None
        for i in range(len(pdf)):
            tp = pdf[i].get_textpage()
            txt = tp.get_text_range()
            if '目' in txt and txt.count('.') > 20:
                loc = i
                break
        if loc is None:
            print('    (未定位到目录页，跳过坐标核对)')
        else:
            pg = pdf[loc]
            W, _H = pg.get_size()
            tp = pg.get_textpage()
            txt = tp.get_text_range()
            rows = collections.defaultdict(list)
            for i in range(len(txt)):
                c = txt[i]
                if c in '\r\n':
                    continue
                x0, y0, x1, y1 = tp.get_charbox(i)
                rows[round(y0)].append((x0, x1, c))
            lm, rm = cm2pt(3.17), W - cm2pt(3.17)
            print('    第 %d 页（0-based）；页宽 %.1fpt，左页边距 %.1fpt，右边界 %.1fpt'
                  % (loc, W, lm, rm))
            for k in sorted(rows, reverse=True)[:12]:
                cells = sorted(rows[k])
                s2 = ''.join(c for _, _, c in cells).strip()
                if not s2:
                    continue
                print('      x_first=%6.1f  x_last=%6.1f  | %s' % (cells[0][0], cells[-1][1], s2[:40]))
            # 栅格化
            for i in range(len(pdf)):
                pdf[i].render(scale=2.2).to_pil().save(os.path.join(wd, 'page%d.png' % (i + 1)))
            print('    已栅格化 %d 页 PNG 到 %s' % (len(pdf), wd))
    except ImportError:
        print('    (未安装 pypdfium2，跳过)')

    # ---------- 结论 ----------
    print('\n=== 结论 ===')
    if problems:
        for p in problems:
            print('  ✗ %s' % p)
        return 1
    print('  ✔ 未发现明显问题')
    return 0


if __name__ == '__main__':
    sys.exit(main())
