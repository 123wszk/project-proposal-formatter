# -*- coding: utf-8 -*-
"""MOST 国家重点研发计划项目申报书 格式调整（离线 python-docx 路径）—— 参考实现 / 起手模板。

用法:
    python format_application_most.py <in.docx> <out.docx>
           [--check] [--keep-blank] [--strip-emphasis] [--keep-track-changes]

    --check              只预演、不落盘（先跑这个，确认区域锚点认得对不对）
    --keep-blank         不做"连续空段合并"（§ 10 的保守开关）
    --strip-emphasis     连 run 级斜体/下划线一起清掉（默认保留，见 § 9.2 / 待确认 #15）
    --keep-track-changes 保留原稿的「修订跟踪」开关（默认在成品里关掉，见 § 9.3）
    STAGES=1 环境变量     每步另存 stage_XX_*.docx，便于二分定位损坏点

对应 references/format-application-most.md 的 § 12 流程：**STEP 0–10 已实现**；
STEP 11（错别字自检，可选项）默认跳过；STEP 12 的"Word 回存刷新域 / 浮动图重插 / 交叉引用"必须人工（§ 11）。

**本脚本不改输入文件**，所有改动只写到 <out.docx> —— "双文件交付"由用法本身保证（§ 12 STEP 12）。

移植到新稿前必须先核对（本脚本含少量稿件特定假设）：
  - 六个区域锚点文本（§ 3.4，见下方 ANCHORS）。先跑 `python diagnose_docx.py 你的稿.docx`
    看实际有哪些段落，再对照 ANCHORS 调谓词；
  - 两张豁免表的判定：靠"表格前紧邻段落文本"识别（项目基本信息表 / 项目参加人员基本情况表）；
  - 若稿里题注已存在（原模板 0 个），本脚本会重复插入 —— 先跑 --check 看"已有题注"计数。

⚠️ 四条硬约束（都踩过，别删）：
  1. **先定位区域区间、再插题注**（§ 8.2）。插题注会新增段落；若先插后定位，锚点位置会漂移 → 区域切分全错。
     本脚本把区域解析成"元素 id 集合"缓存在内存里（PROCESSED_IDS），STEP 7 才插题注，天然满足这个顺序。
  2. **只扫 body 的直接子元素取锚点**（§ 3.4）。用 `body.iter(qn('w:p'))` 会把表格内段落也扫进来，
     锚点位置会算错（"项目基本信息表"本身就可能既出现在页面标题段、又出现在表内说明文字里）。
  3. **区域判定必须按"元素身份"而不是"子元素下标"**。STEP 10 会删空段，下标会整体漂移 ——
     所以全程用 `id(el)` 比对，不用 `a <= idx < b`。
  4. **run 级直接格式必须清**（§ 9.2）。OOXML 优先级 run 级 rPr > 段落标记 pPr/rPr > 样式链 basedOn > docDefaults；
     不清 run 级 `rFonts`/`sz`/`b`，套了样式也不生效（原模板 102 种生效格式签名就是这么来的）。

已知边界（§ 11，脚本做不到的，会进"待人工处理清单"）：
  - 浮动图 wp:anchor → 嵌入型 wp:inline 的转换（必然人工在 Word 里"插入-图片-来自文件"重做）；
  - REF 交叉引用 + _Ref 书签（建议人工用「引用-交叉引用」）；
  - SEQ 域缓存刷新（本脚本写入的缓存值是占位数字，必须用 Word 打开保存一次才算对）；
  - 页码体系 / 页边距（§ 待确认 #17 / #18，明确不在本规范范围）。
"""
import os
import re
import sys

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree

# ----------------------------------------------------------------------------
# 0. 配置常量（全部来自 references/format-application-most.md 的 § 1 / § 4~8）
# ----------------------------------------------------------------------------

FONT_CN = '宋体'
FONT_HEI = '黑体'
FONT_LATIN = 'Times New Roman'      # § 待确认 #11 的默认推荐

SZ_XIAO2 = 36                       # 小二 18pt   → 大标题
SZ_SAN = 32                         # 三号 16pt   → 简介页标题
SZ_SI = 28                          # 四号 14pt   → 中标题 / 简介页正文
SZ_XIAO4 = 24                       # 小四 12pt   → 小标题 / 正文 / 题注
SZ_WU = 21                          # 五号 10.5pt → 表内文字

LINE_15 = '360'                     # 1.5 倍行距 → 240 × 1.5
LINE_EXACT_29 = '580'               # 固定值 29 磅 → 29 × 20 twips
IND_SI = '560'                      # 四号首行缩进 2 字符
IND_XIAO4 = '480'                   # 小四首行缩进 2 字符
IND_CHARS = '200'                   # firstLineChars，与 firstLine 必须成对写

STYLE_BIG = '申报书大标题'
STYLE_MID = '申报书中标题'
STYLE_SMALL = '申报书小标题'
STYLE_TEXT = '申报书正文'
STYLE_INTRO_T = '申报书简介标题'
STYLE_INTRO_B = '申报书简介正文'
STYLE_CAPTION = '申报书题注'
STYLE_TBLE_TXT = '申报书表格文字'

LONG_PARA_LIMIT = 60                # § 5.4 小标题识别保险阈值（待确认 #10）

EXEMPT_TABLE_TITLES = ('项目基本信息表', '项目参加人员基本情况表')   # § 8.4

INPUT = sys.argv[1] if len(sys.argv) > 1 else None
OUTPUT = sys.argv[2] if len(sys.argv) > 2 else None
CHECK = '--check' in sys.argv
KEEP_BLANK = '--keep-blank' in sys.argv
STRIP_EMPHASIS = '--strip-emphasis' in sys.argv
KEEP_REVISIONS = '--keep-track-changes' in sys.argv
STAGES = os.environ.get('STAGES') == '1'

if not INPUT:
    sys.exit(__doc__)
if not CHECK and not OUTPUT:
    sys.exit('用法: python format_application_most.py <in.docx> <out.docx> [--check]\n')

LOG = []
TODO = []                            # 待人工处理清单


def log(*a):
    s = ' '.join(str(x) for x in a)
    LOG.append(s)
    print(s)


def todo(text):
    TODO.append(text)
    log('  [需人工] ' + text)


# ----------------------------------------------------------------------------
# 1. 底层 XML 工具（顺序表照抄 OOXML schema，乱序 Word 会报"文件可能已经损坏"）
# ----------------------------------------------------------------------------

PPR_ORDER = ['w:pStyle', 'w:keepNext', 'w:keepLines', 'w:pageBreakBefore', 'w:framePr',
             'w:widowControl', 'w:numPr', 'w:suppressLineNumbers', 'w:pBdr', 'w:shd',
             'w:tabs', 'w:suppressAutoHyphens', 'w:kinsoku', 'w:wordWrap', 'w:overflowPunct',
             'w:topLinePunct', 'w:autoSpaceDE', 'w:autoSpaceDN', 'w:bidi', 'w:adjustRightInd',
             'w:snapToGrid', 'w:spacing', 'w:ind', 'w:contextualSpacing', 'w:mirrorIndents',
             'w:suppressOverlap', 'w:jc', 'w:textDirection', 'w:textAlignment',
             'w:textboxTightWrap', 'w:outlineLvl', 'w:divId', 'w:cnfStyle', 'w:rPr',
             'w:sectPr', 'w:pPrChange']

RPR_ORDER = ['w:rStyle', 'w:rFonts', 'w:b', 'w:bCs', 'w:i', 'w:iCs', 'w:caps', 'w:smallCaps',
             'w:strike', 'w:dstrike', 'w:outline', 'w:shadow', 'w:emboss', 'w:imprint',
             'w:noProof', 'w:snapToGrid', 'w:vanish', 'w:webHidden', 'w:color', 'w:spacing',
             'w:w', 'w:kern', 'w:position', 'w:sz', 'w:szCs', 'w:highlight', 'w:u', 'w:effect',
             'w:bdr', 'w:shd', 'w:fitText', 'w:vertAlign', 'w:rtl', 'w:cs', 'w:em', 'w:lang',
             'w:eastAsianLayout', 'w:specVanish', 'w:oMath']

# tblPr 的子元素顺序与 pPr 不同，必须单独一张表（w:jc 在 w:tblW 之后）
TBLPR_ORDER = ['w:tblStyle', 'w:tblpPr', 'w:tblOverlap', 'w:bidiVisual',
               'w:tblStyleRowBandSize', 'w:tblStyleColBandSize', 'w:tblW', 'w:jc',
               'w:tblCellSpacing', 'w:tblInd', 'w:tblBorders', 'w:shd', 'w:tblLayout',
               'w:tblCellMar', 'w:tblLook', 'w:tblCaption', 'w:tblDescription', 'w:tblPrChange']

XMLSPACE = '{http://www.w3.org/XML/1998/namespace}space'
NS_WP = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
NS_VML = 'urn:schemas-microsoft-com:vml'


def _ordered_set(parent, tag, attrs, order):
    """在 parent 里按 schema 顺序插入/替换 tag（幂等：先删同 tag 旧元素）。"""
    old = parent.find(qn(tag))
    if old is not None:
        parent.remove(old)
    e = OxmlElement(tag)
    for k, v in (attrs or {}).items():
        e.set(qn(k), str(v))
    idx = order.index(tag)
    for child in parent:
        cfull = 'w:' + etree.QName(child).localname
        if cfull in order and order.index(cfull) > idx:
            child.addprevious(e)
            return e
    parent.append(e)
    return e


def ppr_set(pPr, tag, attrs=None):
    return _ordered_set(pPr, tag, attrs, PPR_ORDER)


def rpr_set(rPr, tag, attrs=None):
    return _ordered_set(rPr, tag, attrs, RPR_ORDER)


def get_pPr(p):
    pPr = p.find(qn('w:pPr'))
    if pPr is None:
        pPr = OxmlElement('w:pPr')
        p.insert(0, pPr)
    return pPr


def run_rpr(r):
    rPr = r.find(qn('w:rPr'))
    if rPr is None:
        rPr = OxmlElement('w:rPr')
        r.insert(0, rPr)
    return rPr


def ppr_no_grid(pPr):
    """§ 1.4 关闭「如果定义了文档网格，则与网格对齐」= 段落级 w:snapToGrid w:val="0"。

    ⚠️ 必须显式写 val="0"：该元素 schema 默认值是 true(=勾选)，**把元素删掉等于没做**。
    ⚠️ 位置由 PPR_ORDER 保证（紧跟 w:adjustRightInd、在 w:spacing / w:ind 之前）。
    ⚠️ 别和 run 级同名元素 w:rPr/w:snapToGrid（字符对字符网格）混淆。
    """
    return ppr_set(pPr, 'w:snapToGrid', {'w:val': '0'})


def drop_children(parent, tags):
    for t in tags:
        e = parent.find(qn(t))
        if e is not None:
            parent.remove(e)


def clean_run_direct_fmt(r, strip_emphasis=False):
    """§ 9.2 run 级直接格式清理：删掉会覆盖样式的 run 级属性。

    - rFonts / sz / szCs / b / bCs 一律删（字体字号加粗交给样式定）；
    - i / u 默认**保留**（可能是作者刻意标记，§ 9.2 / 待确认 #15），--strip-emphasis 才清；
    - 不动 highlight / color / shd（可能是有意标记）。
    """
    rPr = r.find(qn('w:rPr'))
    if rPr is None:
        return
    drop_children(rPr, ['w:rFonts', 'w:sz', 'w:szCs', 'w:b', 'w:bCs'])
    if strip_emphasis:
        drop_children(rPr, ['w:i', 'w:iCs', 'w:u'])
    if len(rPr) == 0:
        r.remove(rPr)


def para_text(p):
    return ''.join((t.text or '') for t in p.iter(qn('w:t')))


def para_runs(p):
    """段落里的 run：直接子元素 + 包在 w:hyperlink / w:smartTag 里的（w:r 不递归进嵌套段落）。"""
    out = []
    for child in p:
        if child.tag == qn('w:r'):
            out.append(child)
        elif child.tag in (qn('w:hyperlink'), qn('w:smartTag')) or \
                etree.QName(child).localname in ('hyperlink', 'smartTag', 'ins', 'del'):
            for r in child.iter(qn('w:r')):
                out.append(r)
    return out


def run_text(r):
    return ''.join((t.text or '') for t in r.iter(qn('w:t')))


def run_sz_half(r):
    """读 run 级字号（半磅）；没有则 None。"""
    rPr = r.find(qn('w:rPr'))
    if rPr is None:
        return None
    sz = rPr.find(qn('w:sz'))
    if sz is None:
        return None
    try:
        return int(sz.get(qn('w:val')))
    except (TypeError, ValueError):
        return None


def make_run_text(txt):
    r = OxmlElement('w:r')
    t = OxmlElement('w:t')
    if txt != txt.strip():
        t.set(XMLSPACE, 'preserve')
    t.text = txt
    r.append(t)
    return r


def make_run_fldchar(fld_type):
    r = OxmlElement('w:r')
    fc = OxmlElement('w:fldChar')
    fc.set(qn('w:fldCharType'), fld_type)
    r.append(fc)
    return r


def make_run_instr(instr):
    r = OxmlElement('w:r')
    it = OxmlElement('w:instrText')
    it.set(XMLSPACE, 'preserve')
    it.text = instr
    r.append(it)
    return r


def is_blank_para(el):
    """空段落判定。⚠️ 有图 / 有对象 / 有分页符的段落**不算空**（否则会被空段合并误删）。"""
    if para_text(el).strip():
        return False
    if el.findall('.//' + qn('w:drawing')):
        return False
    if el.findall('.//' + qn('w:pict')) or el.findall('.//{%s}shape' % NS_VML):
        return False
    if el.findall('.//' + qn('w:object')) or el.findall('.//' + qn('w:br')):
        return False
    return True


def _is_p(el):
    return el.tag == qn('w:p')


def _is_tbl(el):
    return el.tag == qn('w:tbl')


def _norm(t):
    return t.replace('\u3000', ' ').replace(' ', '').strip()


# ----------------------------------------------------------------------------
# 2. 文档与区域切分（§ 3.4 边界定位法）
# ----------------------------------------------------------------------------

doc = Document(INPUT)
body = doc.element.body
children = list(body.iterchildren())

_stage_n = [0]


def snap(name):
    if STAGES and OUTPUT:
        _stage_n[0] += 1
        fn = 'stage_%02d_%s.docx' % (_stage_n[0], name)
        doc.save(fn)
        log('SNAP', fn)


# 六个锚点（§ 3.4 表）。谓词一律用 == / startswith，**不用 in**
# （避免"项目基本信息表"误命中"项目基本信息表页"这类说明文字）。
ANCHORS = [
    ('填报说明页', lambda t: t.startswith('填报说明')),
    ('基本信息表页', lambda t: t.startswith('项目基本信息表')),
    ('简介页', lambda t: t.startswith('申报项目简介')),
    ('正文区', lambda t: re.match(r'^第[一二三四五六七八九十]+部分', t) is not None),
    ('承诺书区', lambda t: t.startswith('国家科技计划项目申报诚信承诺书')
     or t.startswith('国家科技计划项目申报承诺书')),
    ('预算书区', lambda t: t.startswith('项目预算申报书')),
]


def find_anchors():
    found = {}
    cursor = 0
    for name, pred in ANCHORS:
        hit = None
        for i in range(cursor, len(children)):
            el = children[i]
            if not _is_p(el):
                continue
            txt = _norm(para_text(el))
            if not txt:
                continue
            if pred(txt):
                hit = i
                break
        found[name] = hit
        if hit is not None:
            cursor = hit + 1
    return found


_anchor_idx = find_anchors()

log('=' * 76)
log('STEP 2 · 区域切分（只扫 body 直接子元素，共 %d 个子元素）' % len(children))
for name, _ in ANCHORS:
    i = _anchor_idx[name]
    if i is None:
        log('  锚点缺失  %-11s' % name)
    else:
        log('  锚点命中  %-11s  child[%d]  %r' % (name, i, _norm(para_text(children[i]))[:36]))

if _anchor_idx['正文区'] is None:
    sys.exit('致命：找不到正文区锚点（^第X部分）。请先跑 diagnose_docx.py 核对该稿的章节标题写法，'
             '并对照本脚本 ANCHORS 调谓词。')

N = len(children)


def _idx(name, fallback):
    i = _anchor_idx.get(name)
    return fallback if i is None else i


REGIONS = {
    # ---- 不调整区（§ 3.1 / § 3.2 / 已定案） ----
    '封面页':      (0, _idx('填报说明页', N)),
    '填报说明页':  (_idx('填报说明页', 0), _idx('基本信息表页', N)),
    '基本信息表页': (_idx('基本信息表页', 0), _idx('简介页', N)),
    '承诺书区':    (_idx('承诺书区', N), _idx('预算书区', N)),
    '预算书区':    (_idx('预算书区', N), N),
    # ---- 要处理区（要求二 / 要求三~八） ----
    '简介页':      (_idx('简介页', N), _idx('正文区', N)),
    '正文区':      (_anchor_idx['正文区'], _idx('承诺书区', N)),
}

PROCESSED = ('简介页', '正文区')
UNTOUCHED = ('封面页', '填报说明页', '基本信息表页', '承诺书区', '预算书区')

for nm in PROCESSED:
    a, b = REGIONS[nm]
    if a > b:
        sys.exit('致命：区域 %s 的起止锚点顺序颠倒（%d > %d），请检查锚点文本。' % (nm, a, b))
for nm in UNTOUCHED:
    a, b = REGIONS[nm]
    if a > b:
        REGIONS[nm] = (a, a)

for nm in UNTOUCHED + PROCESSED:
    a, b = REGIONS[nm]
    log('  区间  %-13s child[%d, %d)  %d 个子元素' % (nm, a, b, b - a))


def region_elements(name):
    a, b = REGIONS[name]
    return children[a:b]


# ⚠️ 全程用"元素身份"而不是"下级下标"判定区域 —— STEP 10 删空段后下标会漂移
PROCESSED_IDS = set()
for nm in PROCESSED:
    for el in region_elements(nm):
        PROCESSED_IDS.add(id(el))


def in_processed(el):
    return id(el) in PROCESSED_IDS


_body_paras = []      # 要处理的普通段落（可套段落样式）
_cell_paras = []      # 要处理的表格内段落（只加 snapToGrid；run 级另按 § 8.3 改字号）
_proc_tables = []     # 要处理的 body 直属表
for nm in PROCESSED:
    for el in region_elements(nm):
        if _is_p(el):
            _body_paras.append(el)
        elif _is_tbl(el):
            _proc_tables.append(el)
            _cell_paras.extend(el.iter(qn('w:p')))

untouched_tbl = sum(1 for nm in UNTOUCHED for el in region_elements(nm) if _is_tbl(el))
log('  待处理：普通段落 %d · 表内段落 %d · 直属表 %d ｜ 不调整区内的表 %d（跳过）'
    % (len(_body_paras), len(_cell_paras), len(_proc_tables), untouched_tbl))

# 区域内的"豁免表标题段"（如"项目参加人员基本情况表"）—— 要求七明确"标题不动"，整段跳过
def is_exempt_title(p):
    t = _norm(para_text(p))
    return any(t.startswith(x) for x in EXEMPT_TABLE_TITLES)


# ----------------------------------------------------------------------------
# 3. STEP 3 · 建 8 个样式（§ 9.1）
# ----------------------------------------------------------------------------

def handle_track_changes():
    """§ 9.3 文档级设置：修订跟踪。

    ⚠️ 实测坑：科技部申报书模板的 settings.xml 里带着 `<w:trackRevisions w:val="1"/>`
       （修订跟踪是**打开**的）。这样交付后：① 题注编号会被 Word 记成 `w:ins` 修订（红字）；
       ② 用户拿到文件后每敲一个字都被记录。**满篇红色修订的申报书不能交**。
    默认在成品里关掉它（`val="0"`），原始文件不动；`--keep-track-changes` 可保留。
    注：这是**文档级开关**，不属于 § 3 的"区域"范畴，四块不调整区的内容一字未动。
    """
    try:
        st = doc.settings.element
    except Exception:
        return
    tr = st.find(qn('w:trackRevisions'))
    if tr is None:
        return
    val = tr.get(qn('w:val'))
    on = val is None or str(val).lower() not in ('0', 'false', 'off')
    if not on:
        return
    if KEEP_REVISIONS:
        log('  ⚠️ 原稿开着「修订跟踪」，已按 --keep-track-changes 保留 —— '
            '交付前请自行确认是否需要关闭')
        todo('原稿 settings.xml 开着 w:trackRevisions，已保留；如不需要修订标记请在 Word 里关闭')
        return
    tr.set(qn('w:val'), '0')
    log('  ⚠️ 原稿开着「修订跟踪」（settings.xml 的 w:trackRevisions=1）→ 已在成品里关闭')
    log('     （否则题注编号会被记成 w:ins 修订，交付后满篇红字）')
    todo('原稿开着修订跟踪，成品已关闭；若确需保留修订请用 --keep-track-changes 重跑')


handle_track_changes()


def ensure_style(name, kind=WD_STYLE_TYPE.PARAGRAPH):
    try:
        st = doc.styles[name]
    except KeyError:
        st = doc.styles.add_style(name, kind)
    # ⚠️ 必须断 basedOn：原模板 Normal 带 firstLineChars，继承会把首行缩进/悬挂缩进吃掉
    #    （SASTIND 实测坑）。这里一律不挂父样式，随后逐项显式覆盖。
    #    注：规范 § 9.1 建议"题注 basedOn 内置 Caption + 覆盖中文字体"；本脚本改为
    #    完全不挂父样式并显式写全部属性 —— 等效且不受"Caption 样式名是小写"的坑影响（§ 7.2）。
    try:
        st.base_style = None
    except Exception:
        pass
    return st


def style_font(st, ea, latin, sz_half, bold):
    rPr = st.element.get_or_add_rPr()
    rpr_set(rPr, 'w:rFonts', {'w:ascii': latin, 'w:hAnsi': latin, 'w:eastAsia': ea, 'w:cs': latin})
    rpr_set(rPr, 'w:sz', {'w:val': str(sz_half)})
    rpr_set(rPr, 'w:szCs', {'w:val': str(sz_half)})
    if bold:
        rpr_set(rPr, 'w:b', {})
        rpr_set(rPr, 'w:bCs', {})
    else:
        rpr_set(rPr, 'w:b', {'w:val': '0'})
        rpr_set(rPr, 'w:bCs', {'w:val': '0'})


def style_para(st, jc=None, line=None, rule=None,
               first_chars=None, first_line=None, before='0', after='0'):
    pPr = st.element.get_or_add_pPr()
    attrs = {}
    if before is not None:
        attrs['w:before'] = before
    if after is not None:
        attrs['w:after'] = after
    if line is not None:
        attrs['w:line'] = line
        attrs['w:lineRule'] = rule
    if attrs:
        ppr_set(pPr, 'w:spacing', attrs)
    if first_chars is not None or first_line is not None:
        ind = {}
        if first_chars is not None:
            ind['w:firstLineChars'] = first_chars
        if first_line is not None:
            ind['w:firstLine'] = first_line
        ppr_set(pPr, 'w:ind', ind)
    else:
        # 显式清零缩进，避免继承 docDefaults / Normal 的残留
        ppr_set(pPr, 'w:ind', {'w:firstLine': '0', 'w:firstLineChars': '0'})
    if jc:
        ppr_set(pPr, 'w:jc', {'w:val': jc})


STYLE_DEFS = [
    # name,         字体,      字号,      加粗,  jc,       line,           rule,    chars,     firstLine
    (STYLE_BIG,     FONT_CN,  SZ_XIAO2, True,  'center', LINE_15,       'auto',  None,      None),
    (STYLE_MID,     FONT_HEI, SZ_SI,    False, 'left',   LINE_15,       'auto',  None,      None),
    (STYLE_SMALL,   FONT_CN,  SZ_XIAO4, True,  'left',   LINE_15,       'auto',  None,      None),
    (STYLE_TEXT,    FONT_CN,  SZ_XIAO4, False, 'both',   LINE_15,       'auto',  IND_CHARS, IND_XIAO4),
    (STYLE_INTRO_T, FONT_HEI, SZ_SAN,   False, 'center', LINE_EXACT_29, 'exact', None,      None),
    (STYLE_INTRO_B, FONT_CN,  SZ_SI,    False, 'both',   LINE_EXACT_29, 'exact', IND_CHARS, IND_SI),
    (STYLE_CAPTION, FONT_CN,  SZ_XIAO4, False, 'center', LINE_15,       'auto',  None,      None),
]

STYLES = {}
for name, ea, sz, bold, jc, line, rule, chars, fl in STYLE_DEFS:
    st = ensure_style(name)
    style_font(st, ea, FONT_LATIN, sz, bold)
    style_para(st, jc=jc, line=line, rule=rule, first_chars=chars, first_line=fl)
    STYLES[name] = st

# 第 8 个样式：表内文字（字符样式）。实际生效靠 § 8.3 的 run 级直接格式，此处仅为样式体系完整。
st_tbl = ensure_style(STYLE_TBLE_TXT, WD_STYLE_TYPE.CHARACTER)
style_font(st_tbl, FONT_CN, FONT_LATIN, SZ_WU, False)
STYLES[STYLE_TBLE_TXT] = st_tbl

log('=' * 76)
log('STEP 3 · 样式就绪（%d 个）：%s' % (len(STYLES), '、'.join(STYLES.keys())))


def apply_para(p, style_name):
    """把段落切到指定样式：清段落级 + run 级直接格式 → 写 pStyle → 关网格对齐（STEP 9）。"""
    pPr = get_pPr(p)
    drop_children(pPr, ['w:spacing', 'w:ind', 'w:jc'])   # 段落级直接格式会覆盖样式
    ppr_set(pPr, 'w:pStyle', {'w:val': STYLES[style_name].style_id})
    ppr_no_grid(pPr)
    for r in para_runs(p):
        clean_run_direct_fmt(r, STRIP_EMPHASIS)
    mrk = pPr.find(qn('w:rPr'))                          # 段落标记自带的 rPr 同样会覆盖样式
    if mrk is not None:
        drop_children(mrk, ['w:rFonts', 'w:sz', 'w:szCs', 'w:b', 'w:bCs'])
        if len(mrk) == 0:
            pPr.remove(mrk)


# ----------------------------------------------------------------------------
# 4. STEP 4 · 申报项目简介页（§ 4 · 要求二）
# ----------------------------------------------------------------------------

intro_paras = [el for el in region_elements('简介页') if _is_p(el)]
n_intro_t = n_intro_b = 0
for p in intro_paras:
    seg = _norm(para_text(p))
    if not seg:
        ppr_no_grid(get_pPr(p))          # 空段只关网格，不套样式
        continue
    if seg.startswith('申报项目简介') and len(seg) <= 12:
        apply_para(p, STYLE_INTRO_T)
        n_intro_t += 1
    else:
        apply_para(p, STYLE_INTRO_B)
        n_intro_b += 1
log('=' * 76)
log('STEP 4 · 简介页：标题 %d 段（黑体三号／固定29磅）· 正文 %d 段（宋体四号／固定29磅／首行缩进2字符）'
    % (n_intro_t, n_intro_b))
if n_intro_t == 0 and n_intro_b == 0:
    log('  ⚠️ 简介页区间内没有段落被处理 —— 请确认锚点"申报项目简介"命中是否正确。')


# ----------------------------------------------------------------------------
# 5. STEP 5 / 6 · 正文区标题三档 + 正文（§ 5.5 识别算法 / § 6）
# ----------------------------------------------------------------------------

RE_BIG = re.compile(r'^\s*第[一二三四五六七八九十]+部分\s')
RE_MID_FULL = re.compile(r'^[（(]\s*[一二三四五六七八九十]+\s*[）)]')
RE_MID_CN = re.compile(r'^[一二三四五六七八九十]+、')
# 小标题 5 形态（§ 5.4）
RE_SM_1 = re.compile(r'^\d+、')
RE_SM_2 = re.compile(r'^\d+\s')
RE_SM_3 = re.compile(r'^\d+\.\s')          # ⚠️ 必须跟空格，否则 "1.5 倍行距" 会被误判
RE_SM_4 = re.compile(r'^[（(]\d+[）)]')
RE_SM_5 = re.compile(r'^[（(][a-zA-Z][）)]\s*')

body_region_paras = [el for el in region_elements('正文区') if _is_p(el)]
counts = {'big': 0, 'mid': 0, 'small': 0, 'text': 0, 'skip': 0, 'exempt': 0}
big_titles = []

for p in body_region_paras:
    txt = para_text(p)
    seg = _norm(txt)
    if not seg:
        ppr_no_grid(get_pPr(p))
        counts['skip'] += 1
        continue
    if is_exempt_title(p):                       # § 8.4：豁免表的标题"不动"
        counts['exempt'] += 1
        continue

    # § 5.5 优先级短路（简介页已在 STEP 4 处理完，这里只剩正文区）
    if RE_BIG.match(txt):
        apply_para(p, STYLE_BIG)
        counts['big'] += 1
        big_titles.append(seg[:24])
    elif RE_MID_FULL.match(txt) or RE_MID_CN.match(txt):
        apply_para(p, STYLE_MID)
        counts['mid'] += 1
    elif len(seg) <= LONG_PARA_LIMIT and (
            RE_SM_1.match(txt) or RE_SM_2.match(txt) or RE_SM_3.match(txt)
            or RE_SM_4.match(txt) or RE_SM_5.match(txt)):
        apply_para(p, STYLE_SMALL)               # 加粗由样式给（原模板是不加粗的）
        counts['small'] += 1
    else:
        apply_para(p, STYLE_TEXT)
        counts['text'] += 1

log('=' * 76)
log('STEP 5/6 · 正文区：大标题 %d · 中标题 %d · 小标题 %d · 正文 %d · 空段 %d · 豁免标题跳过 %d'
    % (counts['big'], counts['mid'], counts['small'], counts['text'], counts['skip'], counts['exempt']))

CN_NUM = {'一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10}
seq = []
for t in big_titles:
    m = re.match(r'^第([一二三四五六七八九十]+)部分', t)
    if m:
        seq.append(CN_NUM.get(m.group(1)))
log('  大标题序号实测：%s' % seq)
if seq and seq != list(range(1, len(seq) + 1)):
    log('  ❌ 大标题编号不连续（缺号/跳号）—— 本脚本**不自动补**，请人工核对（§ 10）')
    todo('大标题编号不连续：实测 %s，需人工重排' % seq)

# 表内段落只关网格对齐（§ 8.3：不改单元格内的段落属性）
for p in _cell_paras:
    ppr_no_grid(get_pPr(p))

snap('after_titles_body')


# ----------------------------------------------------------------------------
# 6. STEP 10 · 异常字符 / 空段合并（必须在插题注之前做，避免锚点漂移）
# ----------------------------------------------------------------------------

n_empty_run = 0
for p in _body_paras + _cell_paras:
    if p.getparent() is None:
        continue
    for r in list(para_runs(p)):
        if run_text(r).strip():
            continue
        sz = run_sz_half(r)
        if sz is not None and sz <= 11:          # 原模板有 1 处 sz=11（5.5pt）的残留空 run
            p.remove(r)
            n_empty_run += 1
log('=' * 76)
log('STEP 10 · 删除异常小字号空 run：%d 个（判据 sz<=11 且无文字）' % n_empty_run)

n_blank = 0
if KEEP_BLANK:
    log('  连续空段合并：已用 --keep-blank 关闭')
else:
    for nm in PROCESSED:
        run_items = []
        for el in region_elements(nm):
            if _is_p(el) and is_blank_para(el):
                run_items.append(el)
            else:
                if len(run_items) >= 3:
                    for p in run_items[1:]:            # 保留第 1 个
                        pPr = p.find(qn('w:pPr'))
                        if pPr is not None and (
                                pPr.find(qn('w:sectPr')) is not None
                                or pPr.find(qn('w:pageBreakBefore')) is not None):
                            continue                   # 带分节符/分页的绝不删
                        p.getparent().remove(p)
                        n_blank += 1
                run_items = []
        if len(run_items) >= 3:
            for p in run_items[1:]:
                pPr = p.find(qn('w:pPr'))
                if pPr is not None and (
                        pPr.find(qn('w:sectPr')) is not None
                        or pPr.find(qn('w:pageBreakBefore')) is not None):
                    continue
                p.getparent().remove(p)
                n_blank += 1
    log('  连续空段合并（≥3 → 1）：删除 %d 段' % n_blank)


# ----------------------------------------------------------------------------
# 7. STEP 7 · 表格（§ 8 · 要求七）
# ----------------------------------------------------------------------------

children = list(body.iterchildren())          # 刷新（上面删过段落）


def prev_para_text(el, limit=8):
    """该表往上找最近的**非空**段落文本（用于识别"表标题段落"）。

    ⚠️ 必须跳过空段落：原模板里「项目参加人员基本情况表」的标题段与表格之间
       夹着一个空段（child[197]），只看紧邻的上一段会取到 '' → 豁免判定漏掉 → 误加题注。
    """
    cur = el.getprevious()
    steps = 0
    while cur is not None and steps < limit:
        steps += 1
        if _is_p(cur):
            t = _norm(para_text(cur))
            if t:
                return t
        elif _is_tbl(cur):
            break
        cur = cur.getprevious()
    return ''


log('=' * 76)
log('STEP 7 · 表格：body 直属表 %d 个' % sum(1 for el in children if _is_tbl(el)))

cap_count = centered = cell_runs_sz = 0
exempt_hits = []
skipped_tables = []

for el in children:
    if not _is_tbl(el):
        continue
    title = prev_para_text(el)
    exempt = any(title.startswith(x) for x in EXEMPT_TABLE_TITLES)

    if not in_processed(el):
        skipped_tables.append(title or '(无标题)')
        continue

    # --- 7.1 表居中（§ 8.1）---
    tblPr = el.find(qn('w:tblPr'))
    if tblPr is None:
        tblPr = OxmlElement('w:tblPr')
        el.insert(0, tblPr)
    _ordered_set(tblPr, 'w:jc', {'w:val': 'center'}, TBLPR_ORDER)
    centered += 1

    # --- 7.2 表内文字统一宋体五号（run 级直接格式，§ 8.3；嵌套表也照改）---
    for tc in el.iter(qn('w:tc')):
        for r in tc.iter(qn('w:r')):
            if not run_text(r).strip():
                continue
            rPr = run_rpr(r)
            rpr_set(rPr, 'w:rFonts', {'w:ascii': FONT_LATIN, 'w:hAnsi': FONT_LATIN,
                                      'w:eastAsia': FONT_CN, 'w:cs': FONT_LATIN})
            rpr_set(rPr, 'w:sz', {'w:val': str(SZ_WU)})
            rpr_set(rPr, 'w:szCs', {'w:val': str(SZ_WU)})
            cell_runs_sz += 1

    # --- 7.3 题注（豁免表不加，§ 8.4）---
    if exempt:
        exempt_hits.append(title[:16])
        log('  表 %r → 豁免：不加题注、标题不动' % title[:22])
        continue

    cap_count += 1
    cap = OxmlElement('w:p')
    cappPr = OxmlElement('w:pPr')
    cap.append(cappPr)
    ppr_set(cappPr, 'w:pStyle', {'w:val': STYLES[STYLE_CAPTION].style_id})
    ppr_no_grid(cappPr)
    ppr_set(cappPr, 'w:jc', {'w:val': 'center'})
    cap.append(make_run_text('表 '))
    cap.append(make_run_fldchar('begin'))
    cap.append(make_run_instr(' SEQ 表 \\* ARABIC '))
    cap.append(make_run_fldchar('separate'))
    cap.append(make_run_text(str(cap_count)))
    cap.append(make_run_fldchar('end'))
    el.addprevious(cap)                                # ⚠️ 表题在表的**上面**
    log('  表 %r → 题注「表 %d」+ 居中 + 表内五号' % (title[:22], cap_count))

if cap_count:
    todo('题注只插了"表 N"、说明文字留空 —— 需人工补表名（§ 8.2 / 待确认 #12）')
    todo('SEQ 域缓存需刷新：用 Word 打开保存一次（或 Ctrl+A → F9），否则题注显示占位数字')
if skipped_tables:
    log('  跳过（不调整区域内的表）%d 个：%s'
        % (len(skipped_tables), '、'.join(t[:12] for t in skipped_tables)))
log('  汇总：居中 %d 表 · 新增题注 %d 个 · 表内文字改写 %d 个 run' % (centered, cap_count, cell_runs_sz))

# ----------------------------------------------------------------------------
# 8. STEP 8 · 图（§ 7 · 要求六）—— 原模板 0 张图，本节为预防性条款
# ----------------------------------------------------------------------------

n_inline = n_anchor = n_vml = 0
img_paras = []
for p in body_region_paras + intro_paras:
    if p.getparent() is None:
        continue
    if p.findall('.//{%s}inline' % NS_WP):
        n_inline += 1
        img_paras.append(p)
    if p.findall('.//{%s}anchor' % NS_WP):
        n_anchor += 1
    if p.findall('.//{%s}shape' % NS_VML) or p.findall('.//' + qn('w:pict')):
        n_vml += 1

log('=' * 76)
log('STEP 8 · 图：嵌入型 %d · 浮动型(anchor) %d · VML 旧格式 %d' % (n_inline, n_anchor, n_vml))

if n_inline + n_anchor + n_vml == 0:
    log('  稿中无图 → 整节跳过（与原模板实测一致，§ 7）')
else:
    fig_count = 0
    for p in img_paras:
        fig_count += 1
        cap = OxmlElement('w:p')
        cappPr = OxmlElement('w:pPr')
        cap.append(cappPr)
        ppr_set(cappPr, 'w:pStyle', {'w:val': STYLES[STYLE_CAPTION].style_id})
        ppr_no_grid(cappPr)
        ppr_set(cappPr, 'w:jc', {'w:val': 'center'})
        cap.append(make_run_text('图 '))
        cap.append(make_run_fldchar('begin'))
        cap.append(make_run_instr(' SEQ 图 \\* ARABIC '))
        cap.append(make_run_fldchar('separate'))
        cap.append(make_run_text(str(fig_count)))
        cap.append(make_run_fldchar('end'))
        p.addnext(cap)                                 # ⚠️ 图题在图的**下面**
    log('  新增图题注 %d 个（图下方／居中／宋体小四／SEQ 域）' % fig_count)
    if n_anchor:
        todo('检出 %d 处浮动图（wp:anchor）—— 脚本无法转嵌入型，需人工在 Word 里'
             '"插入-图片-来自文件"重做（§ 7.1）' % n_anchor)
    if n_vml:
        todo('检出 %d 处 VML 旧格式图形 —— 同上，需人工重插' % n_vml)

snap('after_tables_figures')


# ----------------------------------------------------------------------------
# 9. 收尾
# ----------------------------------------------------------------------------

if CHECK:
    log('=' * 76)
    log('--check 模式：以上为预演结果，未写出任何文件。')
    log('  请先确认"锚点命中"与各区域段落数符合预期，再正式执行。')
    sys.exit(0)

doc.save(OUTPUT)
log('=' * 76)
log('已写出：%s' % OUTPUT)
log('交付方式：原文件保持不变、成品另存 —— 满足 § 12 STEP 12 的"双文件交付"。')
log('')
log('【需人工处理清单】')
if TODO:
    for i, t in enumerate(TODO, 1):
        log('  %d. %s' % (i, t))
else:
    log('  （无）')
log('')
log('【收尾自检建议】')
log('  1. 用 Word 打开成品 → 无"文件可能已损坏"提示；Ctrl+A → F9 刷新域；另存一次。')
log('  2. 跑 `python diagnose_docx.py 成品.docx` 复核：生效格式签名应从 102 种降到 ≤12 种。')
log('  3. 逐条对照 references/format-application-most.md § 13 的验收清单。')
