# project-proposal-formatter

给**中国式项目申报类文档**（项目建议书 / 申报书 / 任务书 / 投标书）套用特定机构的排版规范的 Skill。

规范按「一类型一文件」组织在 `references/` 下，目前收录了**国防科工局（SASTIND）项目建议书格式要求（V4.2）**。

## 这个 Skill 能做什么

输入一份排版混乱的建议书草稿（`.docx`），输出一份套好规范的成品，处理范围包括：

- **字体字号**：正文宋体小四、标题层级各自字号
- **段落**：1.5 倍行距、首行缩进 2 字符、两端对齐
- **标题**：一/二/三级标题样式统一，并清理 run 级直接格式（否则会覆盖样式定义）
- **章节分页**：各一级章节从新页开始，且不重复分页
- **图表题注**：统一为 Word `Caption` 样式，识别并转换手打的纯文本题注为真正的 SEQ 域，编号顺延纠错
- **表格**：正文区表格居中 + 表内字号统一
- **目录**：主目录 + 图目录 + 表目录
- **页码**：前置区罗马数字、正文阿拉伯数字重新编号
- **异常处理**：章节漏号（自动编号造成的假阳性）、异常字符

## 目录结构

```
project-proposal-formatter/
├── SKILL.md                                  # 技能入口：触发条件、工作流、扩展方式
├── README.md
├── references/
│   └── format-proposal-sastind.md            # 国防科工局项目建议书格式要求（V4.2）
└── scripts/
    ├── diagnose_docx.py                      # 离线诊断：规模统计/样式清单/漏号/异常字符
    └── format_sastind_proposal.py            # SASTIND 格式调整参考实现（python-docx 离线路径）
```

## 安装

把整个 `project-proposal-formatter/` 目录放进你的 Skill 目录：

- **用户级**（所有项目可用）：`~/.workbuddy/skills/`
- **项目级**（团队共享）：`<项目根>/.workbuddy/skills/`

```bash
git clone <本仓库地址> ~/.workbuddy/skills/project-proposal-formatter
```

## 依赖

- **Python 3** + `python-docx`（离线脚本路径用）
  ```bash
  pip install python-docx lxml
  ```
- **文档编辑通道**（可选，取决于宿主环境）：本 Skill 只负责「格式规范 + 编排流程」，实际文档编辑交给宿主的本地文档编辑能力（如实时编辑器 MCP 或批量脚本）。若你的环境没有这些，可直接使用 `scripts/format_sastind_proposal.py` 走离线路径。

## 快速开始

**离线批量路径**（不需要宿主编辑能力）：

```bash
# 1. 先诊断文档现状
python scripts/diagnose_docx.py 你的建议书.docx

# 2. 套用 SASTIND 规范
python scripts/format_sastind_proposal.py 你的建议书.docx 输出.docx

# 调试：只诊断不改（--check）；分步存档以二分定位问题（STAGES=1）
python scripts/format_sastind_proposal.py 输入.docx 输出.docx --check
STAGES=1 python scripts/format_sastind_proposal.py 输入.docx 输出.docx
```

> ⚠️ `format_sastind_proposal.py` 是**参考实现 / 起手模板**，内含稿件特定的硬编码（样式名、重复题注顺延规则）。移植到新文档前请先读它的 docstring 与 references 的 § 13。

## 处理新机构 / 新文档类型

1. 在 `references/` 新建 `format-<文档类型>-<机构简称>.md`（**文档类型在前**，如 `format-application-nsfc.md`）。
2. 套用 `SKILL.md` 里的 reference frontmatter 模板，节数按实际要求增减，不要为凑模板硬写空节。
3. 转写用户给的格式要求文档时**逐段逐条核对**，并主动补全原文没写但实操必备的维度（前置内容、页码体系、章节分页、已有目录/题注处理、异常字符、工具能力边界）。
4. 把「原文没写、由推断补的」条目单独列为**「待用户确认」清单**放在文件末尾。

详见 `SKILL.md` 的 *Extending the Skill* 一节。

## 已知限制

- **域（Field）刷新**：目录、题注编号、交叉引用都是 Word 域。`.docx` 保存时缓存结果不会自动更新，交付后需在 Word/WPS 中按 `Ctrl+A` → `F9` 刷新一次。
- **无 Word COM 的环境**：Linux + WPS 等环境下无法通过自动化接口刷新域，只能靠人工按 F9；同时 WPS 命令行无头转 PDF 在部分发行版上静默失败，无法据此自校验。
- **可选项默认跳过**：如「错别字自检」属可选项，默认不执行，需用户明确要求才跑。

## 版本

- `format-proposal-sastind.md`：**V4.2**
- 变更记录见该文件顶部的元信息。

## 许可

未附加许可证文件。上传到 GitHub 前请按需补充 `LICENSE`（如 MIT / Apache-2.0）。
